Pre-Phase-2 source rollback copies.

Restore the eight files in this archive to the corresponding paths under
MYELIN2.0_ULTIMATE_TRIAL. Then remove the two Phase-2-only source files:
GET_CHART/study_family_evidence.py and ANALYTICS_SHEET/test_phase2_family.py.

This archive does not delete generated PDF, PNG or JPG deliverables.
The original six production files were copied before edits. The two test
files reconstruct only the three Phase-2 assertion wording changes.
